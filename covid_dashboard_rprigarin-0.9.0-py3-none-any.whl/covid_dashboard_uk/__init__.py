import main

__author__ = 'Ruslan Prigarin'
__email__ = 'rp641@exeter.ac.uk'
__version__ = '0.9.0'