import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name='covid-dashboard-rprigarin',
    version='0.9.0',
    author='Ruslan Prigarin',
    author_email='rp641@exeter.ac.uk',
    license='MIT',
    description='Just some covid dashboard written using a couple API libraries and Flask.',
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/rprigarin/covid_dashboard_uk",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operationg System :: OS Independent",
    ],
    include_package_data=True,
    packages=setuptools.find_packages(where="src"),
    package_dir={"": "src"},
    python_requires='>=3.6'

)